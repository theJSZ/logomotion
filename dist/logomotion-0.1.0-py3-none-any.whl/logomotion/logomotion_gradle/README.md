# Gradle Project Base
## Credit
This project base originates from the ev3dev-lang-java repository [template-project-gradle](https://github.com/ev3dev-lang-java/template-project-gradle).
## Purpose
This project base is used for easy deployment of generated Java code into the Lego Mindstorms EV3 Brick.