package classes;

interface Variable {
}
